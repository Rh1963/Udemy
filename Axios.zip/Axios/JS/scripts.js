// 1 Instalação
//     <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
// axios.min.js - Aqui temos um objeto que podemos utilizar na aplicação
// Que utlizamos nas requisições HTTP
console.log(axios);

// 2 - Primeiro request (Requisição)
// Utilizando API de terceiros chamada: json Placeholder
// https://jsonplaceholder.typicode.com/

const getData = async()=>{
    try {
        // Global instance = await axios.get
        // Custom insrance = await postsFetch.get
        const response = await postsFetch.get("https://jsonplaceholder.typicode.com/users", {
            // 4 - Exibindo headers
            // criando o objeto headres
            headers: {
                "Content-Type": "application/json",
                // Podemos criar nossos headers para fugir do padrão, exemplo seria utilização de token para 
                // poder utilizar uma API
                custom: "header"
            }
        });
        return response.data;
    } catch (error) {
        console.log(error);
    }
}

getData()

// 3 - Exibindo dados
// Dica:
// Na página, botão direito -> Inspecionar, Acessar a guia que demonstra
// o tráfego de rede, na guia FETCH/XHR temos as informações da nossa
// requisição API
// FETCH/XHR muito utilizada no desenvolvimento identificando possíveis erros

const container = document.querySelector("#user-container");

const printData = async () => {
    const data = await getData();
    console.log(data);

    data.forEach((user) => {
        const div = document.createElement("div");
        const nameElement = document.createElement("h2");

        nameElement.textContent = user.name;

        div.appendChild(nameElement);
        container.appendChild(div);

        const emailElement = document.createElement("p");
        emailElement.textContent = user.email;

        div.appendChild(emailElement);
    });
}

printData();

// 4 - Exibindo headers
// o código abaixo foi copiado do item 2 para possíveis comparações
// Define como vamos interagir, se com uma API, json e etc
// Novo código inserido no tópico 2

// 5 - POST
const form = document.querySelector("#post-form");
const titleInput = document.querySelector("#title");
const bodyInput = document.querySelector("#body");

// Adicionando evento
form.addEventListener("submit", (e) => {
    // Impede o recarregamento da página, comprtamento padrão do JS
    e.preventDefault();

    // Após a primeira virgula podemos criar o header mas neste caso estamos indo direto para o body
    postsFetch.post("https://jsonplaceholder.typicode.com/posts",{
        // Propridade body
        // body: {title: titleInput.value, body: bodyInput.value, userId: 1}
        // O AXIOS permite que enviemos o body diretamente sem criar a propridade como foi feito na linha acima
        title: titleInput.value, body: bodyInput.value, userId: 1
        // Acima o objeto está sendo convertido para json, o AXIOS está fazendo isso.
    } )
})