const postsFetch = axios.Create({

    baseURL: "https://jsonplaceholder.typicode.com"
})