// Definindo o headers também utlizado em tokens
axios.defaults.headers.commom["Accept"] = "application/json";
// A partir da configuração acima todas nossas requisições serão tratadas com o tipo definido acima
axios.defaults.headers.commom["Authorization"] = "MEUTOKENDOAPP";